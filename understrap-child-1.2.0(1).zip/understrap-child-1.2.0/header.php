<?php
/**
 * The header for our theme
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package Understrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

$bootstrap_version = get_theme_mod( 'understrap_bootstrap_version', 'bootstrap4' );
$navbar_type       = get_theme_mod( 'understrap_navbar_type', 'collapse' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?> <?php understrap_body_attributes(); ?>>
<?php do_action( 'wp_body_open' ); ?>
 
 
	<div class="page-wrapper">

        <div class="site-header__header-one-wrap clearfix">

            <div class="header_top_one">
                <div class="container">
                    <div class="header_top_one_inner clearfix">
                       
                        <div class=" ">
                       
                            <div class=" d-flex gap-3 align-items-center">
                                <a href="<?php echo get_site_url(); ?>" class="w-25"><img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/images/resources/logo.png" alt=""></a>
                                <div class="header_top_one_content_box_bottom_inner clearfix w-75">
                                    <div class="header_top_one_content_box_bottom__social_box">
                                        <div class="header_top_one_content_box_bottom__social">
                                            <a href="#"><i class="fab fa-twitter"></i></a>
                                            <a href="#"><i class="fab fa-facebook-square"></i></a>
                                            <a href="#"><i class="fab fa-dribbble"></i></a>
                                            <a href="#"><i class="fab fa-instagram"></i></a>
                                        </div>
                                    </div>
                                    <div class="header_top_one_content_box_bottom_contact_info">
                                        <ul class="header_top_one_content_box_bottom_contact_info_list list-unstyled">
                                            <li>
                                                <div class="icon">
                                                    <span class="icon-phone-call"></span>
                                                </div>
                                                <div class="text">
                                                    <p>Позвоните нам</p>
                                                    <a href="tel:92-888-000-2222">92 888 000 2222</a>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="icon">
                                                    <span class="icon-message"></span>
                                                </div>
                                                <div class="text">
                                                    <p>Напишите нам</p>
                                                    <a href="mailto:needhelp@company.com">needhelp@company.com</a>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <header class="main-nav__header-one">
                <div class="container">
                    <nav class="header-navigation one stricky">
                        <div class="container-box clearfix">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="main-nav__left main-nav__left_one float-left d-flex gap-3 align-items-center">
                                <a href="#" class="side-menu__toggler">
                                    <i class="fa fa-bars"></i>
                                </a>
                            <?php wp_nav_menu( array( 
    'theme_location' => 'Primary Menu',   'container'       => 'ul',
         'menu_class'      => 'nav mt-2 d-flex gap-4 w-50',) ); ?>
                            <div class="main-nav__right main-nav__right_one float-right w-50">
                                <div class="header_btn_1">
                                    <a href="#addnew" class="thm-btn">Добавить недвижимость</a>
                                </div>
                                <div class="icon_cart_box">
                                    <a href="#">
                                        <span class="icon-shopping-cart"></span>
                                    </a>
                                </div>
                                <div class="icon_search_box">
                                    <a href="#" class="main-nav__search search-popup__toggler">
                                        <i class="icon-magnifying-glass"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </nav>
                </div>
            </header>
        </div>
