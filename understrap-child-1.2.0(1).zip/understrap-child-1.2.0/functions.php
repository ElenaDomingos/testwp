<?php
/**
 * Understrap Child Theme functions and definitions
 *
 * @package UnderstrapChild
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;



/**
 * Removes the parent themes stylesheet and scripts from inc/enqueue.php
 */
function understrap_remove_scripts() {
	wp_dequeue_style( 'understrap-styles' );
	wp_deregister_style( 'understrap-styles' );

	wp_dequeue_script( 'understrap-scripts' );
	wp_deregister_script( 'understrap-scripts' );
}
add_action( 'wp_enqueue_scripts', 'understrap_remove_scripts', 20 );



/**
 * Enqueue our stylesheet and javascript file
 */
function theme_enqueue_styles() {

	// Get the theme data.
	$the_theme = wp_get_theme();

	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	// Grab asset urls.
	$theme_styles  = "/css/child-theme{$suffix}.css";
	$theme_scripts = "/js/child-theme{$suffix}.js";

	wp_enqueue_style( 'child-understrap-styles', get_stylesheet_directory_uri() . $theme_styles, array(), $the_theme->get( 'Version' ) );
	
	wp_enqueue_style( 'child-animate-styles', get_stylesheet_directory_uri() . '/assets/css/animate.min.css' );
	
	wp_enqueue_style( 'child-datapicker-styles', get_stylesheet_directory_uri() . '/assets/css/bootstrap-datepicker.min.css' );
	
	wp_enqueue_style( 'child-select-styles', get_stylesheet_directory_uri() . '/assets/css/bootstrap-select.min.css' );
	
	wp_enqueue_style( 'child-fontawesome-styles', get_stylesheet_directory_uri() . '/assets/css/fontawesome-all.min.css' );
	
	wp_enqueue_style( 'child-gilroy-styles', get_stylesheet_directory_uri() . '/assets/css/gilroy-fonts.css' );
		
	wp_enqueue_style( 'child-jarallax-styles', get_stylesheet_directory_uri() . '/assets/css/jarallax.css' );
		
	wp_enqueue_style( 'child-jquery-ui-styles', get_stylesheet_directory_uri() . '/assets/css/jquery-ui.css' );
		
	wp_enqueue_style( 'child-bootstrap-touchspin-ui-styles', get_stylesheet_directory_uri() . '/assets/css/jquery.bootstrap-touchspin.css' );
		
	wp_enqueue_style( 'child-bxslider-styles', get_stylesheet_directory_uri() . '/assets/css/jquery.bxslider.css' );
		
	wp_enqueue_style( 'child-mCustomScrollbar-styles', get_stylesheet_directory_uri() . '/assets/css/jquery.mCustomScrollbar.min.css' );
	
	
	wp_enqueue_style( 'child-magnific-popup-styles', get_stylesheet_directory_uri() . '/assets/css/magnific-popup.css' );
	
	wp_enqueue_style( 'child-nouislider-styles', get_stylesheet_directory_uri() . '/assets/css/nouislider.min.css' );
		
	wp_enqueue_style( 'child-nouislider.pips-styles', get_stylesheet_directory_uri() . '/assets/css/nouislider.pips.css' );
			
	wp_enqueue_style( 'child-owl-styles', get_stylesheet_directory_uri() . '/assets/css/owl.carousel.min.css' );
	
	wp_enqueue_style( 'child-owl.theme-styles', get_stylesheet_directory_uri() . '/assets/css/owl.theme.default.min.css' );
	
	wp_enqueue_style( 'child-progresscircle-styles', get_stylesheet_directory_uri() . '/assets/css/progresscircle.css' );
	
	wp_enqueue_style( 'child-responsive-styles', get_stylesheet_directory_uri() . '/assets/css/responsive.css' );
	
	wp_enqueue_style( 'child-main-styles', get_stylesheet_directory_uri() . '/assets/css/style.css' );
	
	wp_enqueue_style( 'child-swiper-styles', get_stylesheet_directory_uri() . '/assets/css/swiper.min.css' );
	
	wp_enqueue_style( 'child-tolips-styles', get_stylesheet_directory_uri() . '/assets/css/tolips.css' );
	
	wp_enqueue_style( 'child-vegas-styles', get_stylesheet_directory_uri() . '/assets/css/vegas.min.css' );
	
	wp_enqueue_script( 'jquery' );
	
	
	
	wp_enqueue_script( 'child-understrap-scripts', get_stylesheet_directory_uri() . $theme_scripts, array(), $the_theme->get( 'Version' ), true );
	
	wp_enqueue_script( 'child-appear-scripts', get_stylesheet_directory_uri() . '/assets/js/appear.js' , true );
	
	wp_enqueue_script( 'child-datepicker-scripts', get_stylesheet_directory_uri() . '/assets/js/bootstrap-datepicker.min.js' ,  true );
	
	wp_enqueue_script( 'child-select-scripts', get_stylesheet_directory_uri() . '/assets/js/bootstrap-select.min.js' ,  true );
	
	wp_enqueue_script( 'child-bundle-scripts', get_stylesheet_directory_uri() . '/assets/js/bootstrap.bundle.min.js' , true );
	
	wp_enqueue_script( 'child-countdown-scripts', get_stylesheet_directory_uri() . '/assets/js/countdown.min.js' ,  true );
	
	wp_enqueue_script( 'child-isotope-scripts', get_stylesheet_directory_uri() . '/assets/js/isotope.js' ,  true );
	
	wp_enqueue_script( 'child-jarallax-video-scripts', get_stylesheet_directory_uri() . '/assets/js/jarallax-video.js' ,true );
	
	wp_enqueue_script( 'child-jquery.ajaxchimp-scripts', get_stylesheet_directory_uri() . '/assets/js/jquery.ajaxchimp.min.js' ,  true );
	
	wp_enqueue_script( 'child-jquery-ui-scripts', get_stylesheet_directory_uri() . '/assets/js/jquery-ui.js' , array(), true );
	
	wp_enqueue_script( 'child-bootstrap-touchspin-scripts', get_stylesheet_directory_uri() . '/assets/js/jquery.bootstrap-touchspin.js' ,  true );
	
	wp_enqueue_script( 'child-bxslider.min-scripts', get_stylesheet_directory_uri() . '/assets/js/jquery.bxslider.min.js' ,  true );
	
	wp_enqueue_script( 'child-counterup-scripts', get_stylesheet_directory_uri() . '/assets/js/jquery.counterup.min.js' ,  true );
	
	wp_enqueue_script( 'child-mCustomScrollbar-scripts', get_stylesheet_directory_uri() . '/assets/js/jquery.mCustomScrollbar.concat.min.js' , true );
	
	wp_enqueue_script( 'child-.magnific-popup-scripts', get_stylesheet_directory_uri() . '/assets/js/jquery.magnific-popup.min.js' , true );
	
	wp_enqueue_script( 'child-jquery.min-scripts', get_stylesheet_directory_uri() . '/assets/js/jquery.min.js' ,  true );
	
	wp_enqueue_script( 'child-validate-scripts', get_stylesheet_directory_uri() . '/assets/js/jquery.validate.min.js' , true );
	
	wp_enqueue_script( 'child-nouislider-scripts', get_stylesheet_directory_uri() . '/assets/js/nouislider.min.js' ,  true );
	
	wp_enqueue_script( 'child-owl.carousel-scripts', get_stylesheet_directory_uri() . '/assets/js/owl.carousel.min.js' , true );
	
	wp_enqueue_script( 'child-progresscircle-scripts', get_stylesheet_directory_uri() . '/assets/js/progresscircle.js' , true );
	
	wp_enqueue_script( 'child-swiper-scripts', get_stylesheet_directory_uri() . '/assets/js/swiper.min.js' ,  true );
	
	wp_enqueue_script( 'child-theme-scripts', get_stylesheet_directory_uri() . '/assets/js/theme.js' ,  true );
	
	wp_enqueue_script( 'child-TweenMax-scripts', get_stylesheet_directory_uri() . '/assets/js/TweenMax.min.js' , true );
	
	wp_enqueue_script( 'child-typed-scripts', get_stylesheet_directory_uri() . '/assets/js/typed-2.0.11.js' , true );
	
	wp_enqueue_script( 'child-vegas-scripts', get_stylesheet_directory_uri() . '/assets/js/vegas.min.js' , true );
	
	wp_enqueue_script( 'child-waypoints-scripts', get_stylesheet_directory_uri() . '/assets/js/waypoints.min.js' ,  true );
	
	wp_enqueue_script( 'child-wow-scripts', get_stylesheet_directory_uri() . '/assets/js/wow.js' , true );
	
	
	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );



/**
 * Load the child theme's text domain
 */
function add_child_theme_textdomain() {
	load_child_theme_textdomain( 'understrap-child', get_stylesheet_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'add_child_theme_textdomain' );



/**
 * Overrides the theme_mod to default to Bootstrap 5
 *
 * This function uses the `theme_mod_{$name}` hook and
 * can be duplicated to override other theme settings.
 *
 * @return string
 */
function understrap_default_bootstrap_version() {
	return 'bootstrap5';
}
add_filter( 'theme_mod_understrap_bootstrap_version', 'understrap_default_bootstrap_version', 20 );



/**
 * Loads javascript for showing customizer warning dialog.
 */
function understrap_child_customize_controls_js() {
	wp_enqueue_script(
		'understrap_child_customizer',
		get_stylesheet_directory_uri() . '/js/customizer-controls.js',
		array( 'customize-preview' ),
		'20130508',
		true
	);
}
add_action( 'customize_controls_enqueue_scripts', 'understrap_child_customize_controls_js' );

 

add_action( 'init', 'register_city_post_types' );

function register_city_post_types(){
	 register_post_type('goroda', array(
		'labels'             => array(
			'name'               => 'Города',  
			'singular_name'      => 'Город',  
			'add_new'            => 'Добавить новый',
			'add_new_item'       => 'Добавить новый Город',
			'edit_item'          => 'Обновить Город',
			'new_item'           => 'Новый Город',
			'view_item'          => 'Смотреть Город',
			'search_items'       => 'Найти Город',
			'not_found'          => 'Ничего не найдено',
			'not_found_in_trash' => 'Ничего не найдено в корзине',
			'parent_item_colon'  => '',
			'menu_name'          => 'Города'

		  ),
		'public'             => true,
		'menu_icon'           => 'dashicons-forms',
		'has_archive'        => true,
		'supports'           => array('title','thumbnail', 'editor'),
		'show_in_rest' => false
	) );
	

}

add_action('init', 'register_movel_post_types');

function register_movel_post_types() {
    
   
    register_post_type('nedvijemost', array(
        'labels'             => array(
            'name'               => 'Недвижимость',
            'singular_name'      => 'Недвижимость',
            'add_new'            => 'Добавить новую',
            'add_new_item'       => 'Добавить новую Недвижимость',
            'edit_item'          => 'Обновить Недвижимость',
            'new_item'           => 'Новый Недвижимость',
            'view_item'          => 'Смотреть Недвижимость',
            'search_items'       => 'Найти Недвижимость',
            'not_found'          => 'Ничего не найдено',
            'not_found_in_trash' => 'Ничего не найдено в корзине',
            'parent_item_colon'  => '',
            'menu_name'          => 'Недвижимость'
        ),
        'public'             => true,
        'menu_icon'          => 'dashicons-forms',
        'has_archive'        => true,
        'supports'           => array('title', 'thumbnail', 'editor'),
        'show_in_rest'       => false,
    ));

  
    $taxonomy_labels = array(
        'name'                       => 'Тип недвижимости',  
        'singular_name'              => 'Тип недвижимости',
        'menu_name'                  => 'Тип недвижимости',
        'all_items'                  => 'Все типы недвижимости',
        'parent_item'                => 'Родительский тип недвижимости',
        'parent_item_colon'          => 'Родительский тип недвижимости:',
        'new_item_name'              => 'Новый тип недвижимости',
        'add_new_item'               => 'Добавить новую категорию',
        'edit_item'                  => 'Редактировать категорию',
        'update_item'                => 'Обновить категорию',
        'separate_items_with_commas' => 'Разделяйте тип недвижимости запятыми',
        'search_items'               => 'Искать тип недвижимости',
        'add_or_remove_items'        => 'Добавить или удалить тип недвижимости',
        'choose_from_most_used'      => 'Выбрать из наиболее используемых категорий',
    );

    register_taxonomy('custom_category', 'nedvijemost', array(
        'labels'            => $taxonomy_labels,
        'hierarchical'      => true,   
        'public'            => true,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'type'),   
    ));
}


/* Метабоксы */

 
add_action( 'add_meta_boxes_nedvijemost', 'nedvijemost_add_metabox' );

function nedvijemost_add_metabox() {

	add_meta_box(
		'nedvijemost_metabox', // metabox ID
		'Выберите город', // title
		'nedvijemost_metabox_callback', // callback function
		'nedvijemost', // add meta box to custom post type (or post types in array)
		'normal', // position (normal, side, advanced)
		'default' // priority (default, low, high, core)
	);

}

// it is a callback function which actually displays the content of the meta box
function nedvijemost_metabox_callback( $post ) {

	$city = get_post_meta( $post->ID, '_city', true );
 

	echo '<table class="form-table">
		<tbody>
			<tr>
				<th><label for="city">Выберите город</label></th>
				<td>
					<select id="city" name="city">';
					    
					   $args = array(
	                    'posts_per_page' => -1,
	                    'post_type' => 'goroda');
	                    
                        $goroda_query = new WP_Query( $args );
                        
                        if( $goroda_query->have_posts() ) :
                            
                        while( $goroda_query->have_posts() ) : $goroda_query->the_post();
		 
                    		echo '<option value="'.$goroda_query->post->post_title.'"' . selected( $goroda_query->post->post_title, $city, false ) . '>'.$goroda_query->post->post_title.' </option>';
                    	endwhile;
		            	endif;
    					echo '</select>
				</td>
			</tr>
		</tbody>
	</table>';;
	
}


add_action( 'save_post', 'nedvijemost_save_meta', 10, 2 );


function nedvijemost_save_meta( $post_id, $post ) {

	$post_type = get_post_type_object( $post->post_type );

	if ( ! current_user_can( $post_type->cap->edit_post, $post_id ) ) {
		return $post_id;
	}

 
	if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
		return $post_id;
	}

 
	if( isset( $_POST[ 'city' ] ) ) {
		update_post_meta( $post_id, '_city', sanitize_text_field( $_POST[ 'city' ] ) );
	} else {
		delete_post_meta( $post_id, '_city' );
	}

	return $post_id;

}