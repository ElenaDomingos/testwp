<?php
/*
* Template Name: Главная
*/



get_header();

?>
       <!-- Banner Section One Start -->
        <section class="banner-one">
            <div class="banner-bg-slide"
                data-options='{ "delay": 5000, "slides": [ { "src": "<?php echo get_stylesheet_directory_uri(); ?>/assets/images/main-slider/slider-1-1.jpg" }, { "src": "<?php echo get_stylesheet_directory_uri(); ?>/assets/images/main-slider/slider-1-2.jpg" } ], "transition": "fade", "timer": false, "align": "top", "animation": [ "kenburnsUp", "kenburnsDown", "kenburnsLeft", "kenburnsRight" ] }'>
            </div><!-- /.banner-bg-slide -->
            <div class="container">
                <div class="content-box">
                    <div class="top-title">
                        <h2>Найдите Ваш <br> Дом Мечты</h2>
                    </div>

          
                    <div class="banner_one_bottom_icon_text">
                        <div class="banner_one_bottom_icon">
                            <span class="icon-building"></span>
                        </div>
                        <div class="banner_one_bottom_text">
                            <p>Сервис по публикации объявлений и купли и продаже жилья</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Banner Section One End -->

        <!--Explore One Start-->
        <section class="explore_one">
            <div class="container">
                <div class="block-title text-left">
                    <h4>Найти недвижимость</h4>
                    <h2>В вашем городе</h2>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="explore_one_inner_content">
                            <div class="thm-swiper__slider swiper-container" data-swiper-options='{"spaceBetween": 100, "slidesPerView": 4, "autoplay": { "delay": 5000 }, "pagination": {
                    "el": "#testimonials-one-pagination",
                    "type": "bullets",
                    "clickable": true
                  },
                   "navigation": {
                    "nextEl": ".explore_one_prev",
                    "prevEl": ".explore_one_next",
                    "clickable": true
                },
                   "breakpoints": {
                    "0": {
                        "spaceBetween": 30,
                        "slidesPerView": 1
                    },
                    "425": {
                        "spaceBetween": 30,
                        "slidesPerView": 1
                    },
                    "575": {
                        "spaceBetween": 30,
                        "slidesPerView": 1
                    },
                    "767": {
                        "spaceBetween": 30,
                        "slidesPerView": 1
                    },
                    "991": {
                        "spaceBetween": 20,
                        "slidesPerView": 3
                    },
                    "1289": {
                        "spaceBetween": 30,
                        "slidesPerView": 4
                    },
                    "1440": {
                        "spaceBetween": 30,
                        "slidesPerView": 5
                    }
                }}'>
                                <div class="swiper-wrapper">
                        <?php          
                                     $args = array(
	                    'posts_per_page' => -1,
	                    'post_type' => 'goroda');
	                    
                        $goroda_query = new WP_Query( $args );
                        
                        if( $goroda_query->have_posts() ) :
                            
                        while( $goroda_query->have_posts() ) : $goroda_query->the_post();
		 
                    		echo '
                    		<a href="'.get_permalink().'">
                    		<div class="swiper-slide">
                                        <div class="explore_one_single">
                                            <div class="explore_one_img">
                                            <img src="'.get_the_post_thumbnail_url().'" alt="">
                    		 <div class="explore_one_text">
                                                    <p><a href="listing-1.html">'.$goroda_query->post->post_title.'</a></p>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>';
                    	endwhile;
		            	endif;
		            	
		            	?>
                                   
                                </div>
                            </div>
                            <div class="explore_one_nav">
                                <div class="explore_one_next"><span class="icon-right-arrow"></span></div>
                                <div class="explore_one_prev"><span class="icon-right-arrow"></span> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Explore One End-->

        <!--Why Choose One Start-->
        <section class="why_choose_one jarallax" data-jarallax data-speed="0.2" data-imgPosition="50% 0%"
            style="background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/assets/images/backgrounds/why_choose_one_shape_1.jpg)">
            <div class="container">
                <div class="why_choose_one_title">
                    <h2>Почему нас выбирают</h2>
                </div>
                <div class="why_choose_one_shape_one"
                    style="background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/assets/images/shapes/why_choose_one_shape_1.png)"></div>
                <div class="row">
                    <div class="col-xl-3 col-lg-6 col-md-6">
                        <!--Why Choose One Single-->
                        <div class="why_choose_one_single wow fadeInUp">
                            <div class="why_choose_one_icon">
                                <span class="icon-town"></span>
                            </div>
                            <h3>Найдите дом <br> Мечты</h3>
                            <p>Большой выбор жилья <br> разного типа и цены.</p>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-md-6">
                        <!--Why Choose One Single-->
                        <div class="why_choose_one_single wow fadeInUp" data-wow-delay="100ms">
                            <div class="why_choose_one_icon">
                                <span class="icon-agent"></span>
                            </div>
                            <h3>Опытные  <br> Риелторы</h3>
                            <p>У нас работают опытные<br> специалисты.</p>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-md-6">
                        <!--Why Choose One Single-->
                        <div class="why_choose_one_single wow fadeInUp" data-wow-delay="200ms">
                            <div class="why_choose_one_icon">
                                <span class="icon-assets"></span>
                            </div>
                            <h3>Купите или продайте <br> Недвижимость</h3>
                            <p>Вы можете купить или<br> продать ваше  жилье.</p>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-md-6">
                        <!--Why Choose One Single-->
                        <div class="why_choose_one_single wow fadeInUp" data-wow-delay="300ms">
                            <div class="why_choose_one_icon">
                                <span class="icon-rent"></span>
                            </div>
                            <h3>Список <br> Владельцев</h3>
                            <p>Никаких третьих  лиц</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Why Choose One End-->

        <!--Latest Properties Start-->
        <section class="latest_properties">
            <div class="container">
                <div class="block-title text-center">
                    <h4>Наши последние объявления</h4>
                    <h2>Последние объявления о продаже</h2>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="thm-swiper__slider swiper-container thm-swiper__slider-pause-hover"
                            data-swiper-options='{"spaceBetween": 100, "slidesPerView": 4, "autoplay": { "delay": 5000 }, "pagination": {
                                "el": "#latest_properties_pagination",
                                "type": "bullets",
                                "clickable": true
                            },
                            "navigation": {
                                "nextEl": ".latest_properties_next",
                                "prevEl": ".latest_properties_prev",
                                "clickable": true
                            },
                            "breakpoints": {
                                "0": {
                                    "spaceBetween": 30,
                                    "slidesPerView": 1
                                },
                                "425": {
                                    "spaceBetween": 30,
                                    "slidesPerView": 1
                                },
                                "575": {
                                    "spaceBetween": 30,
                                    "slidesPerView": 1
                                },
                                "767": {
                                    "spaceBetween": 30,
                                    "slidesPerView": 2
                                },
                                "991": {
                                    "spaceBetween": 20,
                                    "slidesPerView": 2
                                },
                                "1289": {
                                    "spaceBetween": 30,
                                    "slidesPerView": 3
                                },
                                "1440": {
                                    "spaceBetween": 30,
                                    "slidesPerView": 3
                                }
                            }}'>
                            <div class="swiper-wrapper">
                         <?php       
                                
                                             $args = array(
	                    'posts_per_page' => -1,
	                    'post_type' => 'nedvijemost');
	                    
                        $goroda_query = new WP_Query( $args );
                        
                        if( $goroda_query->have_posts() ) :
                            
                        while( $goroda_query->have_posts() ) : $goroda_query->the_post();
		 
                        ?>        
                                <div class="swiper-slide">
                                    <div class="latest_properties_single owl-theme owl-carousel">
                                        <div class="latest_properties_img_carousel  ">
                                            <div class="latest_properties_img">
                                                <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="">
                                                <div class="latest_properties_icon">
                                                    <i class="fa fa-heart"></i>
                                                </div>
                                                <div class="featured_and_sale_btn">

                                                   
                                                </div>
                                            </div>
                                             
                                        </div>
                                        <div class="latest_properties_content">
                                            <div class="latest_properties_top_content">
                                                <h4><a href="listing-details.html"><?php echo $goroda_query->post->post_title; ?></a></h4>
                                                <p><?php echo get_field('address'); ?></p>
                                                <h3><?php echo get_field('price'); ?></h3>
                                            </div>
                                            <div class="latest_properties_bottom_content">
                                        
                                            </div>
                                        </div>
                                    </div>
                                </div>
                             <?php 	endwhile;
		            	endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-pagination" id="latest_properties_pagination"></div>
            </div>
        </section>
       
 
   
<?php


get_footer(); 

